﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using C3.XNA;
using Microsoft.Xna.Framework.Audio;

namespace SHLSPong
{
    class Ball:DrawableGameComponent
    {
        const int PIXSIZE = 3;
        const int SCALE = 2;
        Rectangle ball;
        float SPEED = 2.3f;
        Vector2 velocity;
        SpriteBatch spriteBatch;

        public Ball(Game game, SpriteBatch spriteBatch, ContentManager content) : base(game)
        {
            this.spriteBatch = spriteBatch;
            ball = new Rectangle(250 - (2 * PIXSIZE * SCALE), 200-(PIXSIZE*SCALE),  PIXSIZE * SCALE, PIXSIZE * SCALE );

        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();

            spriteBatch.FillRectangle(ball, Color.Yellow);
            spriteBatch.End();

            base.Draw(gameTime);


        }

        public override void Update(GameTime gameTime)
        {
            velocity.X = 0;
            
            velocity = new Vector2(0, 0);
            
            if (ball.Y == (Player.player.Y))
            {
                SPEED = (SPEED * (-1));
                velocity.Y = SPEED;
            }
            if (ball.Y == (Player2.player.Y))
            {
                SPEED = (SPEED * (-1));
                velocity.Y = SPEED;
            }
            else
            {
                velocity.Y = SPEED;
            }

            ball.Y = ball.Y + (int)velocity.Y;
            base.Update(gameTime);

        }

        protected override void LoadContent()
        {
            base.LoadContent();


        }
    }
}
