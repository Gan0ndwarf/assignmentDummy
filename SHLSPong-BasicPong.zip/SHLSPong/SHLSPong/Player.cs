﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using C3.XNA;
using Microsoft.Xna.Framework.Audio;



namespace SHLSPong
{
    public class Player : DrawableGameComponent
    {
        const int PIXSIZE = 16;
        const int SCALE = 2;
       public static Rectangle player;
        const float SPEED = 2.3f;
        Vector2 velocity;
        SpriteBatch spriteBatch;
        public Player(Game game, SpriteBatch spriteBatch, ContentManager content) : base(game)
        {
            this.spriteBatch = spriteBatch;
            player = new Rectangle(250 - (2 * PIXSIZE * SCALE), 350, 2*PIXSIZE * SCALE, PIXSIZE * SCALE/2);

        }
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
           
            spriteBatch.FillRectangle(player, Color.Yellow);
            spriteBatch.End();

            base.Draw(gameTime);


        }

        public override void Update(GameTime gameTime)
        {
            velocity.X = 0;

            velocity = new Vector2(0, 0);
            KeyboardState keyState = Keyboard.GetState();
            if (keyState.IsKeyDown(Keys.Right))
            {
                velocity.X = SPEED;
            }

            if ( keyState.IsKeyDown(Keys.Left))
            {
                velocity.X = -SPEED;
            }
            player.X = player.X + (int)velocity.X;
            player.Y = player.Y + (int)velocity.Y;
            base.Update(gameTime);
            
        }

        protected override void LoadContent()
        {
            base.LoadContent();


        }



    }
}
